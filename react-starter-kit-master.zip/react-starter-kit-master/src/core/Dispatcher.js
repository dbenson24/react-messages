/*! React Starter Kit | MIT License | http://www.reactstarterkit.com/ */

import { Dispatcher } from 'flux';

const dispatcher = new Dispatcher();

export default dispatcher;
